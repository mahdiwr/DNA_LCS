from flask import Flask, request
from LCS import LCS
from FileProcessor import FileProcessor

app = Flask(__name__)

@app.route('/lcs', methods=['POST'])
def calculate_lcs():
    data = request.get_json()
    file_path = data.get('DANs')
    target_phrase = data.get('Shahid')

    file_processor = FileProcessor(file_path)
    most_similar_line, lcs = file_processor.find_most_similar_line(target_phrase)

    return {
        'most_similar_line': most_similar_line,
        'lcs': lcs
    }

@app.route('/')
def index():
    Father_and_Mother = "DNA's.txt"
    Shahid = "shahid.txt"

    with open(Shahid, 'r') as file:
        content = file.read()

    file_processor = FileProcessor(Father_and_Mother)
    most_similar_line, lcs = file_processor.find_most_similar_line(content)
    output_path = r'f:\پروژه طراحی الگوریتم\DNA\output.txt'  # نام فایل و مسیر ذخیره سازی خروجی

    with open(output_path, 'w', encoding='utf-8') as file:
        file.write(f"{content}  {most_similar_line} \t {lcs}")

    return f" {content}  {most_similar_line}\t LCS: {lcs}"



if __name__ == '__main__':
    app.run()
