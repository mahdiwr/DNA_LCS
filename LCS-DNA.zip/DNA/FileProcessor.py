from LCS import LCS
class FileProcessor:
    def __init__(self, file_path):
        self.file_path = file_path

    def find_most_similar_line(self, target_phrase):
        with open(self.file_path, 'r') as file:
            lines = file.readlines()
            max_similarity = 0
            most_similar_line = ''
            lcs = ''

            for line in lines:
                line = line.strip()
                lcs_obj = LCS(line, target_phrase)
                similarity = lcs_obj.calculate_lcs()
                if len(similarity) > max_similarity:
                    max_similarity = len(similarity)
                    most_similar_line = line
                    lcs = similarity
            return most_similar_line, lcs
