class LCS:
    def __init__(self, str1, str2):
        self.str1 = str1
        self.str2 = str2

    def calculate_lcs(self):
        m = len(self.str1)
        n = len(self.str2)
        lcs_table = [[0] * (n + 1) for _ in range(m + 1)]

        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if self.str1[i - 1] == self.str2[j - 1]:
                    lcs_table[i][j] = lcs_table[i - 1][j - 1] + 1
                else:
                    lcs_table[i][j] = max(lcs_table[i - 1][j], lcs_table[i][j - 1])

        lcs_length = lcs_table[m][n]
        lcs = ""
        i = m
        j = n

        while i > 0 and j > 0:
            if self.str1[i - 1] == self.str2[j - 1]:
                lcs = self.str1[i - 1] + lcs
                i -= 1
                j -= 1
            elif lcs_table[i - 1][j] > lcs_table[i][j - 1]:
                i -= 1
            else:
                j -= 1

        return lcs
